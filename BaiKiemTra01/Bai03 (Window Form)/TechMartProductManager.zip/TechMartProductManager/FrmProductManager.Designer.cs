namespace TechMartProductManager;

partial class FrmProductManager
{
    private System.ComponentModel.IContainer? components = null;
    private MenuStrip menuStrip1 = null!;
    private ToolStripMenuItem fileToolStripMenuItem = null!;
    private ToolStripMenuItem exportCsvToolStripMenuItem = null!;
    private ToolStripMenuItem exitToolStripMenuItem = null!;
    private StatusStrip statusStrip1 = null!;
    private ToolStripStatusLabel lblStatus = null!;
    private TableLayoutPanel mainLayout = null!;
    private Panel leftPanel = null!;
    private Panel rightPanel = null!;
    private TextBox txtProductId = null!;
    private TextBox txtProductName = null!;
    private TextBox txtUnitPrice = null!;
    private TextBox txtQuantity = null!;
    private ComboBox cboCategory = null!;
    private PictureBox picAvatar = null!;
    private Button btnChooseImage = null!;
    private Button btnAdd = null!;
    private Button btnUpdate = null!;
    private Button btnDelete = null!;
    private TextBox txtSearch = null!;
    private DataGridView dgvProducts = null!;
    private ErrorProvider errorProvider = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing) components?.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        menuStrip1 = new MenuStrip();
        fileToolStripMenuItem = new ToolStripMenuItem();
        exportCsvToolStripMenuItem = new ToolStripMenuItem();
        exitToolStripMenuItem = new ToolStripMenuItem();
        statusStrip1 = new StatusStrip();
        lblStatus = new ToolStripStatusLabel();
        mainLayout = new TableLayoutPanel();
        leftPanel = new Panel();
        rightPanel = new Panel();
        txtProductId = new TextBox();
        txtProductName = new TextBox();
        txtUnitPrice = new TextBox();
        txtQuantity = new TextBox();
        cboCategory = new ComboBox();
        picAvatar = new PictureBox();
        btnChooseImage = new Button();
        btnAdd = new Button();
        btnUpdate = new Button();
        btnDelete = new Button();
        txtSearch = new TextBox();
        dgvProducts = new DataGridView();
        errorProvider = new ErrorProvider(components);

        menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem });
        fileToolStripMenuItem.Text = "File";
        fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { exportCsvToolStripMenuItem, exitToolStripMenuItem });
        exportCsvToolStripMenuItem.Text = "Export CSV";
        exportCsvToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.E;
        exportCsvToolStripMenuItem.Click += exportCsvToolStripMenuItem_Click;
        exitToolStripMenuItem.Text = "Exit";
        exitToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.X;
        exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;

        statusStrip1.Items.Add(lblStatus);
        lblStatus.Text = "Tổng số sản phẩm: 0";

        mainLayout.ColumnCount = 2;
        mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35F));
        mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 65F));
        mainLayout.Dock = DockStyle.Fill;
        mainLayout.RowCount = 1;
        mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        mainLayout.Controls.Add(leftPanel, 0, 0);
        mainLayout.Controls.Add(rightPanel, 1, 0);

        leftPanel.Dock = DockStyle.Fill;
        rightPanel.Dock = DockStyle.Fill;
        leftPanel.AutoScroll = true;
        rightPanel.Padding = new Padding(10);

        var title = new Label { Text = "THÔNG TIN SẢN PHẨM", AutoSize = true, Font = new Font("Segoe UI", 13F, FontStyle.Bold), Location = new Point(18, 18) };
        leftPanel.Controls.Add(title);
        AddField(leftPanel, "Mã SP", txtProductId, 65);
        AddField(leftPanel, "Tên SP", txtProductName, 105);
        AddField(leftPanel, "Đơn giá", txtUnitPrice, 145);
        AddField(leftPanel, "Số lượng", txtQuantity, 185);

        var lblCategory = new Label { Text = "Danh mục", AutoSize = true, Location = new Point(18, 228) };
        cboCategory.DropDownStyle = ComboBoxStyle.DropDownList;
        cboCategory.Location = new Point(105, 224);
        cboCategory.Width = 190;
        leftPanel.Controls.Add(lblCategory);
        leftPanel.Controls.Add(cboCategory);

        picAvatar.Location = new Point(22, 270);
        picAvatar.Size = new Size(273, 150);
        picAvatar.BorderStyle = BorderStyle.FixedSingle;
        picAvatar.SizeMode = PictureBoxSizeMode.Zoom;
        leftPanel.Controls.Add(picAvatar);

        btnChooseImage.Text = "Chọn ảnh";
        btnChooseImage.Location = new Point(22, 430);
        btnChooseImage.Size = new Size(85, 32);
        btnChooseImage.Click += btnChooseImage_Click;
        leftPanel.Controls.Add(btnChooseImage);

        btnAdd.Text = "Thêm mới";
        btnAdd.Location = new Point(22, 485);
        btnAdd.Size = new Size(85, 34);
        btnAdd.Click += btnAdd_Click;
        leftPanel.Controls.Add(btnAdd);

        btnUpdate.Text = "Cập nhật";
        btnUpdate.Location = new Point(116, 485);
        btnUpdate.Size = new Size(85, 34);
        btnUpdate.Click += btnUpdate_Click;
        leftPanel.Controls.Add(btnUpdate);

        btnDelete.Text = "Xóa";
        btnDelete.Location = new Point(210, 485);
        btnDelete.Size = new Size(85, 34);
        btnDelete.Click += btnDelete_Click;
        leftPanel.Controls.Add(btnDelete);

        var lblSearch = new Label { Text = "Tìm kiếm:", AutoSize = true, Location = new Point(10, 14) };
        txtSearch.Location = new Point(80, 10);
        txtSearch.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        txtSearch.Width = 420;
        txtSearch.TextChanged += txtSearch_TextChanged;
        rightPanel.Controls.Add(lblSearch);
        rightPanel.Controls.Add(txtSearch);

        dgvProducts.Location = new Point(10, 48);
        dgvProducts.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvProducts.Size = new Size(600, 480);
        dgvProducts.AutoGenerateColumns = false;
        dgvProducts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvProducts.MultiSelect = false;
        dgvProducts.AllowUserToAddRows = false;
        dgvProducts.ReadOnly = true;
        dgvProducts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvProducts.SelectionChanged += dgvProducts_SelectionChanged;
        dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Mã SP", DataPropertyName = "ProductId" });
        dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Tên SP", DataPropertyName = "ProductName" });
        dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Danh mục", DataPropertyName = "Category" });
        dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Đơn giá", DataPropertyName = "UnitPrice", DefaultCellStyle = new DataGridViewCellStyle { Format = "N0 'VND'" } });
        dgvProducts.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Số lượng", DataPropertyName = "Quantity" });
        rightPanel.Controls.Add(dgvProducts);

        errorProvider.ContainerControl = this;

        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(1000, 620);
        Controls.Add(mainLayout);
        Controls.Add(statusStrip1);
        Controls.Add(menuStrip1);
        MainMenuStrip = menuStrip1;
        MinimumSize = new Size(850, 560);
        StartPosition = FormStartPosition.CenterScreen;
        Text = "TechMart Product Manager";
    }

    private static void AddField(Control parent, string labelText, TextBox textBox, int y)
    {
        var label = new Label { Text = labelText, AutoSize = true, Location = new Point(18, y + 4) };
        textBox.Location = new Point(105, y);
        textBox.Width = 190;
        parent.Controls.Add(label);
        parent.Controls.Add(textBox);
    }
}
